dalixjarvis - Android ilova (1-versiya)

O'RNATISH
1. Android Studio'ni yuklab o'rnating: https://developer.android.com/studio
2. Zipni oching, Android Studio'da File > Open orqali "dalixjarvis-android" papkasini tanlang.
3. Birinchi ochilganda Gradle sinxronlanishini kuting (bir necha daqiqa, internet kerak).
4. Telefonda: Sozlamalar > Telefon haqida > "Build number"ga 7 marta bosing > Dasturchi parametrlari > "USB debugging"ni yoqing.
5. Telefonni kabel bilan kompyuterga ulang va Android Studio yuqorisidagi yashil "Run" tugmasini bosing.

BUYRUQLAR
- "Telegramni och", "YouTube'ni och"
- "6 ga budilnik qo'y", "kechqurun 9:30 ga budilnik qo'y"
- "chiroqni yoq", "chiroqni o'chir"
- "qo'ng'iroq qil 998901234567"
- "ob-havo qidir"
- "soat nechi"
