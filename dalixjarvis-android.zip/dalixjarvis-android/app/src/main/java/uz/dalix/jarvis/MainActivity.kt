package uz.dalix.jarvis

import android.Manifest
import android.app.Activity
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {

    private lateinit var logBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var micButton: Button
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        addMessage("Salom, men Jarvisman. Masalan: \"Telegramni och\", \"6 ga budilnik qo'y\", \"chiroqni yoq\", \"qo'ng'iroq qil 998901234567\", \"ob-havo qidir\".", false)
    }

    // ---------- Ko'rinish ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A121A"))
            setPadding(dp(16), dp(40), dp(16), dp(12))
        }

        val title = TextView(this).apply {
            text = "dalixjarvis"
            setTextColor(Color.parseColor("#3FD0EA"))
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(logBox) }
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = dp(12); bottomMargin = dp(12) })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        micButton = Button(this).apply {
            text = "Gapirish"
            setOnClickListener { toggleListening() }
        }
        row.addView(micButton)

        input = EditText(this).apply {
            hint = "Buyruq yozing..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#8AA0AE"))
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { submitText(); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val send = Button(this).apply {
            text = "OK"
            setOnClickListener { submitText() }
        }
        row.addView(send)

        root.addView(row)
        setContentView(root)
    }

    private fun addMessage(text: String, fromUser: Boolean) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(if (fromUser) Color.parseColor("#04202A") else Color.parseColor("#E6F1F6"))
            setBackgroundColor(if (fromUser) Color.parseColor("#3FD0EA") else Color.parseColor("#111D28"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(8)
            gravity = if (fromUser) Gravity.END else Gravity.START
        }
        logBox.addView(tv, lp)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun submitText() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        handleCommand(t)
    }

    // ---------- Ovozni tanish ----------

    private fun toggleListening() {
        if (listening) {
            recognizer?.stopListening()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("Telefoningizda ovozni tanish xizmati yo'q. Buyruqni yozib bering.", false)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening = true
                micButton.text = "Eshityapman..."
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                listening = false
                micButton.text = "Gapirish"
                addMessage("Eshitolmadim, qayta urinib ko'ring.", false)
            }
            override fun onResults(results: Bundle?) {
                listening = false
                micButton.text = "Gapirish"
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (text.isNullOrBlank()) {
                    addMessage("Eshitolmadim, qayta urinib ko'ring.", false)
                } else {
                    handleCommand(text)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        }
        recognizer?.startListening(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toggleListening()
            } else {
                addMessage("Mikrofon ruxsati berilmadi. Buyruqni yozib bera olasiz.", false)
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    // ---------- Buyruqlarni bajarish ----------

    private val cyr = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "yo",
        'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m",
        'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u",
        'ф' to "f", 'х' to "x", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'ъ' to "", 'ы' to "i",
        'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ў' to "o", 'қ' to "q", 'ғ' to "g",
        'ҳ' to "h"
    )

    /** Kichik harf, kirillni lotinga o'tkazadi, tutuq belgilarini olib tashlaydi. */
    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when {
                ch == '\'' || ch == '’' || ch == 'ʻ' || ch == 'ʼ' || ch == '`' || ch == '‘' -> {}
                cyr.containsKey(ch) -> sb.append(cyr[ch])
                else -> sb.append(ch)
            }
        }
        return sb.toString().trim()
    }

    private fun handleCommand(raw: String) {
        addMessage(raw, true)
        val t = normalize(raw)

        // Chiroq
        if (t.contains("chiroq") || t.contains("fonar")) {
            val turnOff = t.contains("ochir") || t.contains("yopgin") || t.contains("yop")
            setTorch(!turnOff)
            return
        }

        // Budilnik
        if (t.contains("budilnik") || t.contains("uygotgich")) {
            val m = Regex("(\\d{1,2})(?:[:. ](\\d{2}))?").find(t)
            if (m == null) {
                addMessage("Qaysi soatga qo'yay? Masalan: \"6 ga budilnik qo'y\".", false)
                return
            }
            var hour = m.groupValues[1].toInt()
            val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
            if ((t.contains("kech") || t.contains("tush")) && hour < 12) hour += 12
            if (hour > 23 || minute > 59) {
                addMessage("Vaqtni tushunmadim.", false)
                return
            }
            try {
                val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                }
                startActivity(i)
                addMessage("Budilnik %02d:%02d ga qo'yildi.".format(hour, minute), false)
            } catch (e: Exception) {
                addMessage("Budilnik ilovasi topilmadi.", false)
            }
            return
        }

        // Qo'ng'iroq (raqam bilan)
        if (t.contains("qongiroq") || t.contains("telefon qil") || t.contains("call")) {
            val digits = t.filter { it.isDigit() || it == '+' }
            if (digits.length < 3) {
                addMessage("Raqamni ayting. Masalan: \"qo'ng'iroq qil 998901234567\".", false)
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
                addMessage("$digits raqami terildi, yashil tugmani bosing.", false)
            } catch (e: Exception) {
                addMessage("Telefon ilovasi topilmadi.", false)
            }
            return
        }

        // Qidirish
        if (t.contains("qidir")) {
            val q = t.replace(Regex("qidirib ber|qidirgin|qidiring|qidir"), "").trim()
            if (q.isEmpty()) {
                addMessage("Nimani qidiray?", false)
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                addMessage("\"$q\" qidirilmoqda.", false)
            } catch (e: Exception) {
                addMessage("Qidirish uchun brauzer topilmadi.", false)
            }
            return
        }

        // Soat
        if (Regex("\\bsoat\\b").containsMatchIn(t) && t.contains("nech")) {
            val c = Calendar.getInstance()
            addMessage("Hozir soat %02d:%02d.".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)), false)
            return
        }

        // Ilovani ochish: "<nomi> och", "<nomi>ni och", "<nomi>ni ishga tushir"
        val open = Regex("^(.*?)\\s*(och|ochgin|oching|ochib ber|ishga tushir|ishga tushiring)\\b.*$").find(t)
        if (open != null) {
            val name = open.groupValues[1].trim()
            if (name.isNotEmpty()) {
                if (launchApp(name)) return
                if (name.endsWith("ni") && name.length > 3 && launchApp(name.dropLast(2))) return
                addMessage("\"$name\" ilovasini topa olmadim.", false)
                return
            }
        }

        addMessage("Buyruqni tushunmadim. Ilovani ochish, budilnik, chiroq, qo'ng'iroq va qidirishni bilaman.", false)
    }

    private fun launchApp(name: String): Boolean {
        val key = name.filter { it.isLetterOrDigit() }
        if (key.isEmpty()) return false
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)

        // Avval aniq moslik, keyin qisman moslik
        val ordered = apps.sortedBy { ri ->
            val label = normalize(ri.loadLabel(pm).toString()).filter { it.isLetterOrDigit() }
            if (label == key) 0 else 1
        }
        for (ri in ordered) {
            val label = normalize(ri.loadLabel(pm).toString()).filter { it.isLetterOrDigit() }
            if (label.isEmpty()) continue
            if (label == key || label.contains(key) || (key.length >= 4 && key.contains(label))) {
                val launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: continue
                return try {
                    startActivity(launch)
                    addMessage("${ri.loadLabel(pm)} ochildi.", false)
                    true
                } catch (e: Exception) {
                    false
                }
            }
        }
        return false
    }

    private fun setTorch(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                addMessage("Telefonda chiroq topilmadi.", false)
                return
            }
            cm.setTorchMode(id, on)
            addMessage(if (on) "Chiroq yoqildi." else "Chiroq o'chirildi.", false)
        } catch (e: Exception) {
            addMessage("Chiroqni boshqara olmadim.", false)
        }
    }
}
